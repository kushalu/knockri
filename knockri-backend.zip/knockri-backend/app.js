


const express = require("express");
const app = express();
const mongoose = require("mongoose");

const bodyParser = require("body-parser");



const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();

// db
// mongodb://kaloraat:dhungel8@ds257054.mlab.com:57054/nodeapi
// MONGO_URI=mongodb://localhost/nodeapi
//mongoose
//.connect(process.env.MONGO_URI, { useNewUrlParser: true })
//.connect("mongodb://localhost/tableapp", { useNewUrlParser: true })
//mongoose.connect('mongodb://localhost:27017/knockril', { useNewUrlParser: true })
mongoose.connect('mongodb://user:user123@ds255728.mlab.com:55728/knokri', { useNewUrlParser: true }/*)
  .then(() => console.log("DB Connected"));

mongoose.connection.on("error", err => {
  console.log(`DB connection error: ${err.message}`);
}*/
  , function (error) {
    if (error) {
      console.log(error)
    } else {
      console.log("connected to the database")
    }
  }
);

app.use(bodyParser.json());
// bring in routes
const userRoutes = require("./routes/users");
// apiDocs
/*app.get("/api", (req, res) => {
  fs.readFile("docs/apiDocs.json", (err, data) => {
    if (err) {
      res.status(400).json({
        error: err
      });
    }
    const docs = JSON.parse(data);
    res.json(docs);
  });
});*/

// middleware -



app.use(cors());

app.use("/", userRoutes);


app.use(function (err, req, res, next) {
  if (err.name === "UnauthorizedError") {
    res.status(401).json({ error: "Unauthorized!" });
  }
});

const port = process.env.PORT || 8080
app.listen(port, () => {
  console.log(`A Node Js API is listening on port: ${port}`);
});
