const Candidates = require("../models/candidates")

const Questions = require("../models/questions")
const Comments = require("../models/comment")
const Applications = require("../models/applications")

exports.candidateById = (req, res, next, id) => {
  Candidates.findById(id)
    // populate followers and following users array

    .exec((err, user) => {
      if (err || !user) {
        return res.status(400).json({
          error: "candidate not found"
        });
      }
      candidate = user;
      console.log(user)
      // adds profile object in req with user info
      next();
    });

};
exports.Addcandidate = (req, res) => {

  const addcandidate = new Candidates(req.body)

  console.log(addcandidate)
  addcandidate.save((err, result) => {
    if (err) {
      return res.status(400).json({
        error: err
      })
    }
    else {
      res.status(200).json(

        result)
    }
  })

}


exports.Addquestion = (req, res) => {

  const addquestion = new Questions(req.body)


  addquestion.save((err, result) => {
    if (err) {
      return res.status(400).json({
        error: err
      })
    }
    else {
      res.status(200).json(

        result)
    }
  })

}

// Add applications

exports.Addapplication = (req, res) => {

  const addapp = new Applications(req.body)


  addapp.save((err, result) => {
    if (err) {
      return res.status(400).json({
        error: err
      })
    }
    else {
      res.status(200).json(

        result)
    }
  })

}

/*exports.getcandidates = (req, res) => {



}*/

exports.getCandidates = (req, res) => {
  //console.log(req.query.fname)



  Candidates.find()

    .exec((err, candidates) => {
      if (err) {
        return res.status(400).json({
          error: "Employees not found"
        })
      }

      res.json(candidates)
    })

};
exports.getCandidateid = (req, res) => {
  //const cid = req.body.id
  const cid = candidate._id
  Candidates.find({ _id: cid })

    .exec((err, candidates) => {
      if (err) {
        return res.status(400).json({
          error: "Employees not found"
        })
      }

      res.json(candidates)
    })

}

exports.getApplicationid = (req, res) => {
  //const cid = req.body.id
  const aid = req.params.aid
  console.log(aid + "aid")
  Applications.find({ aid: aid })

    .exec((err, applications) => {
      if (err) {
        return res.status(400).json({
          error: "Application not found"
        })
      }

      res.json(applications)

    })

}

exports.AddComment = (req, res) => {

  const addcomment = new Comments(req.body)


  addcomment.save((err, result) => {
    if (err) {
      return res.status(400).json({
        error: err
      })
    }
    else {
      res.status(200).json(

        result)
    }
  })

}
exports.getComment = (req, res) => {
  console.log("abcd")
  //const name = req.params.commentname
  const name = req.params.name
  console.log(name)
  Comments.find({ name: name }).exec((err, data) => {
    if (err) {
      res.status(400).json("error in finding a data")
    }
    else {
      res.status(200).json(...data)
      console.log(data)
    }

  })
}
