const mongoose = require("mongoose");
//const { ObjectId } = mongoose.Schema;

const applicationSchema = new mongoose.Schema({
  aid: {
    type: Number
  },
  /*videos: {
    type: String

  }*/
  videos: {
    type: Array, "default": [{
      src: "",
      questionId: "",
      comments: ""
    }]
  }


},
  { timestamps: true }

);



module.exports = mongoose.model("Applications", applicationSchema);