const mongoose = require("mongoose");
//const { ObjectId } = mongoose.Schema;

const candidateSchema = new mongoose.Schema({
  name: {
    type: String
  },
  applicationId: {
    type: String

  }



},
  { timestamps: true }

);



module.exports = mongoose.model("Candidates", candidateSchema);