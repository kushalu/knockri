const mongoose = require("mongoose");
//const { ObjectId } = mongoose.Schema;

const commentSchema = new mongoose.Schema({
  cid: {
    type: String,
  },

  comment: {
    type: String,
  }


},
  { timestamps: true }

);



module.exports = mongoose.model("Comments", commentSchema);