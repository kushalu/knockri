const mongoose = require("mongoose");
//const { ObjectId } = mongoose.Schema;

const questionSchema = new mongoose.Schema({
  qid: {
    type: String
  },
  question: {
    type: String

  },




},
  { timestamps: true }

);



module.exports = mongoose.model("Questions", questionSchema);