const mongoose = require("mongoose");
//const { ObjectId } = mongoose.Schema;

const employeeSchema = new mongoose.Schema({



  fname: {
    type: String
  },
  lname: {
    type: String
    //  requried: "product is required"
  },
  gender: {
    type: String
    //  requried: "product is required"
  },
  address: {
    type: String
  },
  dob: {
    type: Date
  },



},
  { timestamps: true },
  { expireAfterSeconds: 3 }
);



module.exports = mongoose.model("Employee", employeeSchema);