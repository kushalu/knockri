const express = require("express");

const { Addcandidate, Addquestion, Addapplication, getCandidates, getCandidateid, candidateById, getApplicationid, AddComment, getComment } = require("../controllers/emps")
const router = express.Router();

router.post("/addapp", Addapplication)
router.post("/addcandidate", Addcandidate)
router.post("/addquestion", Addquestion)
router.get("/candidates", getCandidates)
router.get("/candidateid/:candId", getCandidateid)
router.get("/applicationid/:aid", getApplicationid)
router.post("/addcomment", AddComment)
router.get("/getcomment/:name", getComment)


router.param("candId", candidateById);


module.exports = router;
