

export const candidates = () => {
  return fetch(`http://localhost:8080/candidates`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",

    }
  })
    .then(response => { //
      return response.json()

    })
    .catch(err => console.log(err));
}
export const Addemp = (user) => {
  return fetch("http://localhost:8080/addemp", {// we are using curly brace and the function as to return  ->> so used return keyword 
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-type": "application/json"
    },
    body: JSON.stringify(user)
  })
    .then(response => {
      return response.json()
    })
    .catch(err => console.log(err));
}


export const candidate = (canId) => {

  return fetch(`http://localhost:8080/candidateid/${canId}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",

    }
  })
    .then(response => {

      return response.json()

    })
    .catch(err => console.log(err));
}

export const application = (aid) => {
  console.log(aid + "aid")
  return fetch(`http://localhost:8080/applicationid/${aid}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",

    },
    //body: JSON.stringify(aid)
  })
    .then(response => {

      return response.json()
      console.log(response.json() + "aid")
    })
    .catch(err => console.log(err));
}

export const addComment = (user) => {
  return fetch("http://localhost:8080/addcomment", {// we are using curly brace and the function as to return  ->> so used return keyword 
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-type": "application/json"
    },
    body: JSON.stringify(user)
  })
    .then(response => {
      return response.json()
    })
    .catch(err => console.log(err));
}

export const getcomment = (canId) => {
  console.log(canId)
  return fetch(`http://localhost:8080/getcomment/${canId}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",

    },
    //body: JSON.stringify(aid)
  })
    .then(response => {

      return response.json()
      console.log(response.json())
    })
    .catch(err => console.log(err));
}
