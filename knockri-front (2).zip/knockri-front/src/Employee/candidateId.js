import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { candidate, application, addComment, getcomment } from "./api/candidateapi"
import { Player, BigPlayButton } from 'video-react';
import 'bootstrap/dist/css/bootstrap.min.css';
class Getcandidate extends Component {
  constructor() {
    super()
    this.state = {
      id: "",
      name: "",
      aid: "",
      videos: [],
      comment: "",
      comments: [],
      vid: "123",
      error: ""
    }
  }
  init = canId => {
    //const token = isAuthenticated().token;
    candidate(canId).then(data => {
      console.log(data)
      if (data.error) {
        this.setState({ redirectToProfile: true });
      } else {
        this.setState({
          id: data[0]._id,
          name: data[0].name,
          aid: data[0].applicationId
        });
        const aid = this.state.aid
        console.log(aid)
        application(aid).then(data => {
          // console.log(data[0].aid + "aid")
          if (data.error) {
            this.setState({ redirectToProfile: true });
          } else {
            this.setState({

              videos: data[0].videos

            });


          }
        });
      }
    });
    //
    //

  };
  /* com = (canId) => {
 
   getcomment(canId).then(data => {
      // console.log(data[0].aid + "aid")
      if (data.error) {
        this.setState({ comments: [] });
      } else {
        this.setState({

          comments: data

        });


      }
    });

     
   }*/
  componentDidMount() {
    //this.userData = new FormData();
    const canId = this.props.match.params.canId;
    //const name = this.state.name;
    //const n = this.state.name;
    //console.log(n)
    //console.log(name + "inside a component did mount")
    console.log(canId)
    this.init(canId);
    //this.com(canId);



  }

  /*handleChange = (comment) = event => {

    this.setState({ comment: event.taret.value })
  }
*/
  handleChange = (comment) => (event) => {
    this.setState({ error: "" })//-> when user inserting a input after getting error it will vanish by itself 
    this.setState({ [comment]: event.target.value })
  };

  ClickSubmit = event => {
    event.preventDefault()// to not to reload by defualt 


    const { name, comment } = this.state;
    // now to create object and send it to the backend 

    const user = {
      name,
      comment

    }

    addComment(user).then(data => {
      if (data.error) this.setState({ error: data.error });
      else
        this.setState({
          error: "",

          comment: "",
          open: true
        })





    })
  };

  ClickSubmitComment = event => {
    event.preventDefault()// to not to reload by defualt 


    const { name, comment } = this.state;
    // now to create object and send it to the backend 

    const user = {
      name,
      comment

    }
    var con = this.state.name
    getcomment(con).then(data => {
      if (data.error) this.setState({ error: data.error });
      else
        this.setState({
          error: "",

          comments: data,
          open: true
        })

      console.log(this.state.comments + "comments")



    })
  };
  render() {

    return (
      <div >
        <div className="row">
          <div style={{ width: "30%" }} > </div>
          {this.state.comments}
          <div style={{ width: "40%" }}>

            <div>Candidate Name:&nbsp;{this.state.name}</div>
            <div>Candidate Id:&nbsp;{this.state.aid}</div>

            <div>
              {this.state.videos.map(function (item, key) {
                return (

                  <div key={key}>

                    <div>{item.questionId}</div>
                    <div>{item.src}</div>
                    <Player>
                      <source src={item.src} width="20" />

                    </Player>
                  </div>



                )
              })}

            </div>
          </div>
          <div style={{ width: "30%" }} ><div> </div>
            <form>
              <div className="form-group">
                <lable className="text-muted">Add comment</lable>
                <input onChange={this.handleChange("comment")} value={this.state.comment} type="text" className="form-control" />
              </div>
              <button className="button.btn.btn-raised btn-primary" onClick={this.ClickSubmit}>add comment</button>
            </form>
            <button className="button.btn.btn-raised btn-primary" onClick={this.ClickSubmitComment}>Click to view comments</button>
            <div>view comments </div>
            <div>

              {this.state.comments.map(function (item, key) {
                return (

                  <div key={key}>

                    <div>{item.comment}</div>

                  </div>



                )
              })}

            </div>
          </div>
        </div>
      </div>
    );


  }
}
export default Getcandidate