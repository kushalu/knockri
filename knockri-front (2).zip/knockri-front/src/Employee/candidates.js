
import React from "react";
import ReactDOM from "react-dom";
import { Link } from "react-router-dom"
import 'bootstrap/dist/css/bootstrap.min.css';
//import "./styles.css";
import "./index.css"
import upanddown from "./images/upanddown.png";
import { candidates } from "./api/candidateapi"
import delete1 from "./images/delete.png";
import update from "./images/edit.png";
import { Button } from 'react-bootstrap';
function searchingFor(searchField) {
  return function (x) {
    return x.name.toLowerCase().includes(searchField.toLowerCase()) || !searchField

  }
}

class Employeelist extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      // selectedProduct: "",
      // batches: [],
      // quantities: [],
      // prices: [],
      data: [],
      searchField: "",
      data2: [],
      sucess: false,
      error: "",

      data3: [],
      data4: [],
      data5: [],

      items: [

        {
          row: "1",

        },
        {
          row: "3",

        },
        {
          row: "5",

        },
        {
          row: "10",


        },
        {
          row: "20",

        },
        {
          row: "50",

        },
        {
          row: "Full",
        }

      ]
    };
    this.handleChange = this.handleChange.bind(this)
    //this.removeEmployee = this.removeEmployee.bind(this)
    //this.removeItem = this.removeItem.bind(this)
  }

  componentDidMount() {

    fetch(`http://localhost:8080/candidates`)

      .then(response => response.json())
      .then(users => this.setState({ data: users, data3: users, data4: users, data5: users }))
  }

  onRowChange = event => {

    const data = this.state.data;
    const data2 = this.state.data2;
    const data3 = this.state.data3;
    const data4 = this.state.data4;
    //console.log(data2)
    // const d = this.state.data

    const row1 = event.target.value;

    console.log(row1)
    // if (data === row1) {
    if (row1 === "Full") {
      /* this.setState({
 
         data: data4
 
       })*/
      window.location.reload(true);
    } else {
      this.setState({

        data: data3.slice(0, row1)

      })
    }

    //}  data.push(data3)
    data3.pop()

  };

  handleChange = event => {
    //searchField = this.state.searchField
    const data = this.state.data;
    const searchField = this.state.searchField
    //console.log(event.target.value)
    // const searchField = event.target.value
    const search = event.target.value;
    //console.log(search)
    //console.log(event.target.value)
    //this.setState({ searchField: search });
    this.setState({

      searchField: search

    })
    console.log("searchField")
    console.log(this.state.searchField)
  }
  deleteProduct(productId) {

    console.log(productId)

  }

  render() {
    const { data } = this.state;

    const uniqueItems = [
      ...new Set(this.state.items.map(item => item.row))
    ];

    return (

      <div style={{ backgroundColor: "#FFFAFA" }}>

        <div className="jumbotron" style={{ backgroundColor: "#7B68EE", height: "300px", textAlign: "center", color: "white" }}>
          <div>  <b style={{ fontSize: "34px" }}>Welcome to Loreium ipsum </b></div>
          is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
        </div>
        <div className="container">
          <div> <h1>Candidates</h1></div><br></br>
          <Link to="/addemployee"><button className="addperson"> Add Person</button> </Link>
          {/* First select */}
          <div className="row">
            <div style={{ width: "50%", marginLeft: "2%" }}>
              <div className="row">
                <div style={{ paddingLeft: "10px", fontSize: "15px" }}> show </div> <select className="form-control" onChange={this.onRowChange} style={{ width: "60px", height: "30px", fontSize: "12px" }}>
                  <option value="">..</option>
                  {uniqueItems.map(item => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select> <div style={{ fontSize: "15px" }}>entries</div>
              </div>
            </div>
            <div style={{ width: "26%", }}></div>
            <div style={{ width: "10%", }}>
              <div className="row">
                <div style={{ width: "50%", fontSize: "12px", textAlign: "center" }}>
                  search here</div>
                <div style={{ width: "10%" }}>
                  {/*<input type="text" onChange={e =>
                    this.setState({ searchField: e.target.value }, () => console.log(this.state.searchField)
                    )

                  } />*/}
                  <input type="text" onChange={this.handleChange} placeholder="search by name" />
                </div>
              </div>
            </div>
          </div>
          <br></br>
          <table style={{ width: "100%" }}>
            {/*<div className="row" style={{ backgroundColor: "lightblue" }}>

              <div style={{ width: "15%", fontSize: "20px" }}><b>Fname</b></div>
              <div style={{ width: "15%" }}><b>Lname</b></div>
              <div style={{ width: "15%" }}><b>Gender</b></div>
              <div style={{ width: "15%" }}><b>Address</b></div>
              <div style={{ width: "20%" }}><b>Date of Birth</b></div>
              <div style={{ width: "15%" }}><b>Action</b></div>
            </div> */}
            <tr>
              <th style={{ width: "15%" }}>Fname<img src={upanddown} width="15" height="15" style={{ float: "right" }} />  </th>

              <th style={{ width: "15%" }}>Actions<img src={upanddown} width="15" height="15" style={{ float: "right" }} />  </th>



            </tr>
            {this.state.data.filter(searchingFor(this.state.searchField)).map(function (item, key) {
              return (

                <tr key={key}>

                  <td >{item.name}</td>

                  <td style={{ width: "160px" }}><button className="edit"> <img src={update} width="15" height="15" /><Link style={{ color: "white" }} to={item._id}>View </Link> </button>

                  </td>
                </tr>

              )
            })}

            <tr>
              {/*<th >Fname</th>

              <th> Action</th>*/}
            </tr>

          </table>
          showing 1 to  {this.state.data.length} of {this.state.data5.length} entries
        <table></table>
        </div>
      </div >
    );
  }
}
export default Employeelist