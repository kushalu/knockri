//import 'React' from 'react';
import React /*{ Component }*/ from 'react';
import { Route, Switch } from 'react-router-dom';


import candidates from './Employee/candidates.js'
import candid from './Employee/candidateId'

/*import Signup from './user/Signup';
import Signin from './user/Signin'; */


const MainRouter = () => (<div>

  <Switch>

    <Route exact path="/:canId" component={candid} />
    <Route exact path="/" component={candidates} />




  </Switch>
</div>
);

export default MainRouter;
